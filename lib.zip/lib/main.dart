import 'dart:async';

import 'package:flutter/material.dart';

import 'models/employee_model.dart';
import 'models/location_history.dart';
import 'services/api_service.dart';
import 'theme/app_theme.dart';
import 'widgets/dashboard_header.dart';
import 'widgets/employee_card.dart';
import 'widgets/history_table.dart';
import 'widgets/map_widget.dart';
import 'widgets/statistics_cards.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Employee Live Tracker',
      theme: AppTheme.lightTheme,
      home: const DashboardScreen(),
    );
  }
}

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final ApiService apiService = ApiService();

  Employee? employee;

  bool isLoading = true;
  String? errorMessage;

  late Timer timer;

  final List<LocationHistory> history = [];

  Future<void> fetchLocation() async {
    try {
      final result = await apiService.fetchLocation();

      setState(() {
        employee = result;
        isLoading = false;
        errorMessage = null;

        history.insert(
          0,
          LocationHistory(
            time: result.time,
            latitude: result.latitude,
            longitude: result.longitude,
            address: result.address,
          ),
        );

        if (history.length > 20) {
          history.removeLast();
        }
      });
    } catch (e) {
      setState(() {
        isLoading = false;
        errorMessage = e.toString();
      });
    }
  }

  @override
  void initState() {
    super.initState();

    fetchLocation();

    timer = Timer.periodic(const Duration(seconds: 3), (_) => fetchLocation());
  }

  @override
  void dispose() {
    timer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return Scaffold(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        body: const Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircularProgressIndicator(),
              SizedBox(height: 20),
              Text("Loading Live Location...", style: TextStyle(fontSize: 16)),
            ],
          ),
        ),
      );
    }

    if (errorMessage != null) {
      return Scaffold(
        body: Center(
          child: Card(
            child: Padding(
              padding: const EdgeInsets.all(30),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.cloud_off, color: Colors.red, size: 70),
                  const SizedBox(height: 20),
                  Text(errorMessage!),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: fetchLocation,
                    child: const Text("Retry"),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    }

    return Scaffold(
      body: RefreshIndicator(
        onRefresh: fetchLocation,
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              const DashboardHeader(),

              const SizedBox(height: 20),

              const StatisticsCards(),

              const SizedBox(height: 20),

              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    width: 340,
                    child: AnimatedSwitcher(
                      duration: const Duration(milliseconds: 400),
                      child: EmployeeCard(
                        key: ValueKey(employee!.time),
                        employee: employee!,
                      ),
                    ),
                  ),

                  const SizedBox(width: 20),

                  Expanded(
                    flex: 3,
                    child: SizedBox(
                      height: 600,
                      child: MapWidget(
                        latitude: employee!.latitude,
                        longitude: employee!.longitude,
                      ),
                    ),
                  ),

                  const SizedBox(width: 20),

                  SizedBox(width: 300, child: _buildRightPanel()),
                ],
              ),

              SizedBox(
                width: double.infinity,
                child: HistoryTable(history: history),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildRightPanel() {
    return Column(
      children: [
        _infoCard(
          Icons.location_on,
          "Latitude",
          employee!.latitude.toString(),
          Colors.blue,
        ),

        const SizedBox(height: 15),

        _infoCard(
          Icons.public,
          "Longitude",
          employee!.longitude.toString(),
          Colors.green,
        ),

        const SizedBox(height: 15),

        _infoCard(
          Icons.speed,
          "Speed",
          "${employee!.speed} km/h",
          Colors.orange,
        ),

        const SizedBox(height: 15),

        _infoCard(
          Icons.battery_full,
          "Battery",
          "${employee!.battery}%",
          Colors.purple,
        ),

        const SizedBox(height: 15),

        _infoCard(
          Icons.access_time,
          "Last Updated",
          employee!.time,
          Colors.red,
        ),
      ],
    );
  }

  Widget _infoCard(IconData icon, String title, String value, Color color) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: color.withOpacity(.15),
          child: Icon(icon, color: color),
        ),
        title: Text(title),
        subtitle: Text(
          value,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}

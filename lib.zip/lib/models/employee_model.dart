class Employee {
  final String name;
  final double latitude;
  final double longitude;
  final String time;
  final String status;
  final String address;
  final double speed;
  final int battery;

  Employee({
    required this.name,
    required this.latitude,
    required this.longitude,
    required this.time,
    required this.status,
    required this.address,
    required this.speed,
    required this.battery,
  });

  factory Employee.fromJson(Map<String, dynamic> json) {
    return Employee(
      name: json['name'],
      latitude: (json['latitude'] as num).toDouble(),
      longitude: (json['longitude'] as num).toDouble(),
      time: json['time'],
      status: json['status'],
      address: json['address'],
      speed: (json['speed'] as num).toDouble(),
      battery: json['battery'],
    );
  }
}


